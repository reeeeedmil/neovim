vim.g.mapleader = " "

